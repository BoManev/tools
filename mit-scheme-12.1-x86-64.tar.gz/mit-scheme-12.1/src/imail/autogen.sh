#!/bin/sh

set -e
autoreconf --force --install
